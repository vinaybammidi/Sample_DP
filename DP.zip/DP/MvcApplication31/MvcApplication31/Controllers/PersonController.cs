﻿using MvcApplication31.Models;
using MvcApplication31.Models.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication31.Controllers
{
    public class PersonController : Controller
    {
        //
        // GET: /Person/
        private _IAllRepository<Person> personObject;
          public PersonController()
        {
            this.personObject = new AllRepository<Person>();
        }
        public ActionResult Index()
        {
            return View(from m in personObject.GetModel() select m);
        }

        //
        // GET: /Person/Details/5

        public ActionResult Details(int id)
        {
            Person b = personObject.GetModelByID(id);
            return View(b);
        }

        //
        // GET: /Person/Create

        public ActionResult Create()
        {

            return View();
        }

        //
        // POST: /Person/Create

        [HttpPost]
        public ActionResult Create(Person collection)
        {
            try
            {
                // TODO: Add insert logic here
                personObject.InsertModel(collection);
                personObject.save();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Person/Edit/5

        public ActionResult Edit(int id)
        {
            Person b = personObject.GetModelByID(id);
            return View(b);
        }

        //
        // POST: /Person/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, Person collection)
        {
            try
            {
                // TODO: Add update logic here
                personObject.UpdateModel(collection);
                personObject.save();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Person/Delete/5

        public ActionResult Delete(int id)
        {
            Person b = personObject.GetModelByID(id);
            return View(b);
        }

        //
        // POST: /Person/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, Person collection)
        {
            try
            {
                // TODO: Add delete logic here
                personObject.DeleteModel(id);
                personObject.save();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
